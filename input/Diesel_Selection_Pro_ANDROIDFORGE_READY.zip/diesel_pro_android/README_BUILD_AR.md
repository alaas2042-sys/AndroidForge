# Diesel Selection Pro — Android APK

هذا المشروع جاهز للفتح في Android Studio وبناء APK قابل للتثبيت والمشاركة.

## البناء
1. افتح المجلد `diesel_pro_android` في Android Studio.
2. انتظر Gradle Sync وثبّت Android SDK المطلوب إذا طلب البرنامج ذلك.
3. من القائمة: **Build > Build APK(s)**.
4. ستجد APK التجريبي عادةً داخل: `app/build/outputs/apk/debug/app-debug.apk`.

## نسخة Release للمشاركة
استخدم **Build > Generate Signed Bundle / APK > APK**، ثم أنشئ keystore خاصًا بالتطبيق.

## ملاحظة
تم تضمين قاعدة بيانات المولدات داخل صفحة التطبيق لتعمل بدون إنترنت وبلا اعتماد على Excel.
